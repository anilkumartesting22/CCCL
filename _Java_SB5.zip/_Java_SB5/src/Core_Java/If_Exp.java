package Core_Java;

public class If_Exp {

	public static void main(String[] args) {
		int a=67+12;
		if(a<231)
		{
			System.out.println("Condition pass");
		}
		else
		{
			System.out.println("Condition fail");
		}

	}

}
