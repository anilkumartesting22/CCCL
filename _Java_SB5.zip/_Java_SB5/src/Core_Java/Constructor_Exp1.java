package Core_Java;

public class Constructor_Exp1 {
	static String name;
	static int id;
	Constructor_Exp1(String name1,int ids)
	{
		this.name=name1;
		this.id=ids;
	}
	void Java()
	{
		System.out.println("Hi...");
	}
	public static void main(String[] args) {
		Constructor_Exp1 obj=new Constructor_Exp1("Anil", 56);
		
	}

}
