package Core_Java;
abstract class julio
{
	abstract void keka();
	abstract void forms();
}
class dumro
{
	public void keka()
	{
		System.out.println("hi");
	}
}
class jijili extends dumro
{
 public void forms()
 {
	 System.out.println("hello");
 }
}
public class Abs_traction {

	public static void main(String[] args) {
		jijili obj=new jijili();
		obj.keka();
		obj.forms();
	}

}
