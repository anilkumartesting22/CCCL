package Core_Java;

public class First_Upper_Case {

	public static void main(String[] args) {
		//store the data
		String name="selenium";
		//get the length
		int len=name.length();
		//print first letter ucase
		String first=name.substring(0, 1);
		//print remaining letters
		String remainig=name.substring(1,name.length());
		//print first letter upper case
		String u_case=first.toUpperCase();
		//add the both first+rem
		String full_name=u_case+remainig;
		System.out.println(full_name);
		

	}

}
