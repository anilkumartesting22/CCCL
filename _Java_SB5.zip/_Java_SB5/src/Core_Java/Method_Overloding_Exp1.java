package Core_Java;

public class Method_Overloding_Exp1 {
  public void Java(int a,String name)
  {
	  System.out.print(a);
	  System.out.print(name);
  }
  public void Java(String name1,String name2)
  {
	  System.out.println(name1);
	  System.out.println(name2);
  }
  public void Java(String name5,int id)
  {
	  System.out.println(name5);
	  System.out.println(id);
  }
	public static void main(String[] args) {
		Method_Overloding_Exp1 obj=new Method_Overloding_Exp1();
		obj.Java(23, " Selenium");
		obj.Java(" python", 10);
		obj.Java(" RPI", "Tablue");
		

	}

}
