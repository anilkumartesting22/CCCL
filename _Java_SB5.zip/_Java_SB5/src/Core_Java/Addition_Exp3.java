package Core_Java;

public class Addition_Exp3 {
	public void Add(int a,int b)
	{
		int c=a+b;
		System.out.println(c);
	}
	public void div(int d,int e)
	{
		int g=d/e;
		System.out.println(g);
		
	}
	public void Mul(int i,int j)
	{
		int k=i*j;
		System.out.println(k);
	}

	public static void main(String[] args) {
		Addition_Exp3 obj=new Addition_Exp3();	
		obj.Add(105, 56);
		obj.div(55, 5);
		obj.Mul(23, 12);

	}

}
