package Core_Java;

public class MultiLavel_ClassB extends  MultiLavel_ClassA{
	String name="Selenium with java";
	public void Hi(String name, String name2)
	{
		System.out.println(name);
		System.out.println(name2);
	}

	public static void main(String[] args) {
		MultiLavel_ClassB obj=new MultiLavel_ClassB();
		//here i want execute Class A-2 and B-1
		System.out.println(obj.name);//---->Class B
		System.out.println(obj.div());//---->Class A
		obj.Add();//class A
		
		
		

	}

}
