package Core_Java;
import java.util.*;
public class HashMap_Exp1 {

	public static void main(String[] args) {
		//syntax of HashMap 
		HashMap<String,Integer> emp=new HashMap<String,Integer>();
		//we need to store the info
		emp.put("Selenium", 45);
		emp.put("Python", 25);
		emp.put("Cobal", 12);
		emp.put("Jira", 67);
		emp.put("Tablue", 35);
		emp.put("Core", 78);
		//we need to get the data from HashMap
		System.out.println(emp.get("Python"));
		System.out.println(emp.get("Core"));
		System.out.println("============");
		//if we want get only data
		//we need to use KeySet method
		for(String emps: emp.keySet())
		{
			System.out.println("The name of Employees is:"+emps);
		}
		System.out.println("============");
		//if we want print employee id's
		for(Integer ids:emp.values())
		{
			System.out.println("The Employee's id's is:"+ids);
		}
		System.out.println("============");
	}

}
