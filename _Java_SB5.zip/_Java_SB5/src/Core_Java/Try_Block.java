package Core_Java;

public class Try_Block {

	public static void main(String[] args) {
		try
		{
			int a=45/0;
			System.out.println(a);
		}catch(ArithmeticException e)
		{
			System.out.println("this is Error of number formate");
		}
		finally
		{
			int b=30+23;
			System.out.println(b);
		}

	}

}
