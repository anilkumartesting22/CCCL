package Core_Java;

public class String_Occurence {

	public static void main(String[] args) {
		//we need to store the String
		String name="java programing language";
		//get the length
		int before=name.length();//30-a
		//count expectd Char
		int after=name.replaceAll("g", "").length();
		int count=before-after;
		System.out.println("The number of count a is:"+count);
		
//30,25
		//30-25=5
		
	}

}
