package Core_Java;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.io.IOException;
public class File_Writer_Exp {

	public static void main(String[] args) throws IOException {
	//location of the text file
		FileWriter file=new FileWriter("C:\\Users\\DELL\\Desktop\\Samudra.txt");
		//create the Object of Buffereadwriter
		BufferedWriter br=new BufferedWriter(file);
		//write the data
		br.write("java with Selenium");
		br.write(" selenium easy tool");
		System.out.println("The data is Available");
		br.close();

	}

}
