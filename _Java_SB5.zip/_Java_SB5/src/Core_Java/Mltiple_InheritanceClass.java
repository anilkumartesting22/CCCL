package Core_Java;
interface Selenium
{
	public static void java()
	{
		System.out.println("Hello");
	}
	
}
interface python
{
	public static void Core()
	{
		System.out.println("Hi");
	}
}
interface C extends Selenium,python
{

	
}

