package Core_Java;

public class Constractor_Exp {
	 Constractor_Exp()
	{
		
	}
	public void Hi()
	{
		System.out.println("Hello");
	}

	public static void main(String[] args) {
		Constractor_Exp obj=new Constractor_Exp(); 
		obj.Hi();

	}

}
