package Core_Java;

public class Swaping_Exp {

	public static void main(String[] args) {
		int a=20, b=30;
		System.out.println("Before swaping the value..:"+ a + " "+b);
//		int l=a;
//		a=b;//20=30
//		b=l;//30=20
//		l=b;//20=30
		a=a+b;//50
		b=a-b;//50-30=20
		a=a-b;//50-20=30
		System.out.println("After Swaping the value is :"+a+" "+b);
				

	}

}
