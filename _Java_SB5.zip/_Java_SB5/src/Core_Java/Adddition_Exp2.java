package Core_Java;

public class Adddition_Exp2 {
	//Accessspe_ret_meth()
	public static void Add()
	{
		int a=45+23;
		System.out.println("The value of addition is.:"+a);
	}
	public void Div()
	{
		int b=35/5;
		System.out.println("The value of Div is.:"+b);
		
		
	}
	public void Mul()
	{
		int c=34*90;
		System.out.println("The value of Mul is.:"+c);
	}
	public void Sub()
	{
		int d=256;
		int h=113;
		int o=d-h;
		System.out.println("The value of sub is.:"+o);
	}
	

	public static void main(String[] args) {
		Adddition_Exp2 obj=new Adddition_Exp2();
		obj.Sub();
		obj.Div();
		Adddition_Exp2.Add();
		obj.Mul();

	}

}
