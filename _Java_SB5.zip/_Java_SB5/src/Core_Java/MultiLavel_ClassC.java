package Core_Java;

public class MultiLavel_ClassC extends MultiLavel_ClassB{
	String Emp_name="GunaShekar Athota";
	public void hello()
	{
		System.out.println("This is just Hello");
	}

	public static void main(String[] args) {
		//we are able to access Class A methods and Class B methods with
		//extends class B in side class C
		MultiLavel_ClassC obj=new MultiLavel_ClassC();
		obj.Sub();//--------------->Class A
		obj.Mul();//------------->Class A
		obj.Hi("Selenium", "Core Java");//------>Class B
		System.out.println(obj.Emp_name);//---->Class C
		obj.hello();//Class C
		
	}

}
