package Core_Java;

public class Max_Ans_MIn_Exp {

	public static void main(String[] args) {
		//store the Expexted Values
		int[] a= {4,23,76,41,56,6,3,5,17,86,26};
		//just we need to provide 
		int max=a[0];
		//we need to use loop 
		for(int i=0;i<a.length;i++)

		{
			//we need to provide condition
			if(a[i]<max)
			{
				max=a[i];
			}
		}
		System.out.println("The Max value is:"+max);
	}

}
