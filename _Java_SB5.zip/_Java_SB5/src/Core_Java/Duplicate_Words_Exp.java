package Core_Java;

public class Duplicate_Words_Exp {

	public static void main(String[] args) {
		String[] a= {"java","Pychaon","Tablue","java","pychaon"};
		boolean temp=false;
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]==a[j])
				{
					System.out.println("The dulicate word is:"+a[j]);
					temp=true;
				}
			
		}
			
		}
		

	}

}
