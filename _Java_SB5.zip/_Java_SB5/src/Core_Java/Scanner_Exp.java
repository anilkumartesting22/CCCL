package Core_Java;
import java.util.*;
public class Scanner_Exp {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Mr Anil please provide Expected number");
		int a=sc.nextInt();
		System.out.println("Mr Anil please enter Second Value");
		int b=sc.nextInt();
		int c=a+b;
		System.out.println(c);
		
		

	}

}
