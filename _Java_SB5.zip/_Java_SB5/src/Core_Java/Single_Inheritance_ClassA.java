package Core_Java;

public class Single_Inheritance_ClassA {
	String name="Selenium very easy tool";
	String name2=" With out practice it's very difficult";
	public void Add()
	{
		int a=23+56;
		System.out.println(a);
	}
	public void div()
	{
		int b=45/5;
		System.out.println(b);
	}
	

}
