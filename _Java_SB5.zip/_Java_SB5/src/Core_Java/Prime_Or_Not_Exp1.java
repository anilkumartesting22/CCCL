package Core_Java;

public class Prime_Or_Not_Exp1 {

	public static void main(String[] args) {
		int num=5;
		int count=0;
		for(int i=1;i<=num;i++)
		{
			if(num%i==0)
			{
				count++;
			}
		}
       if(count==2)
       {
    	   System.out.println("That is Prime number");
       }
       else
       {
    	   System.out.println("That is not a Prime number");
       }
	}

}
