package Core_Java;

public class String_Equals_Exp {

	public static void main(String[] args) {
		String name="automation with java";
		String name1="automation with java";
		if(name.equals(name1))
		{
			System.out.println("both are same");
		}
		else
		{
			System.out.println("both are not same");
		}
		String name4="HyDERaBAd";
		String name5="hYDerAbAd";
		if(name4.equalsIgnoreCase(name5))
		{
			System.out.println("Second both are same");
		}
		else
		{
			System.out.println("Second both are not same");
		}

	}

}
