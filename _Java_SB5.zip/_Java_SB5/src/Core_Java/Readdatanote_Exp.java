package Core_Java;
import java.io.*;
public class Readdatanote_Exp {

	public static void main(String[] args) throws IOException {
		//read the data form notepad
		FileReader con=new FileReader("C:\\Users\\DELL\\Desktop\\Samudra.txt");
		//create BuffrReader object
		BufferedReader br=new BufferedReader(con);
		String str;
		while((str=br.readLine())!=null)
		{
			System.out.println(str);
		}

	}

}
