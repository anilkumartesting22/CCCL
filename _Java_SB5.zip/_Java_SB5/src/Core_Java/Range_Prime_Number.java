package Core_Java;

import java.util.Scanner;

public class Range_Prime_Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stu
         int min,max,i,j;
         Scanner sc=new Scanner(System.in);
         System.out.println("Please Eneter Min Value");
         min=sc.nextInt();
         System.out.println("Please Enter Max Value");
         max=sc.nextInt();
         for(i=min;i<=max;i++)
         {
        	 for(j=2;j<i;j++)
        	 {
        		 if(i%j==0)
        			 break;
        	 }
        	 
        	 if(i==j)
        	 {
        		 System.out.println("The values is:" + j + " ");
        	 }
         }
         
        		 
	}

}
