package Core_Java;

import java.util.HashMap;
import java.util.Map;

public class Count_Character {
     static void count(String input)
    {
    	//create the syntax of HashMap
    	HashMap<Character,Integer>Charcount=new HashMap<Character,Integer>();
    	char[] count=input.toCharArray();
    	for(char b:count)
    	{
    		if(Charcount.containsKey(b))
    		{
    			Charcount.put(b, Charcount.get(b)+1);
    		}
    		else
    		{
    			Charcount.put(b, 1);
    		}
         for(Map.Entry entry:Charcount.entrySet())
		{
			System.out.println(entry.getKey()+"  "+entry.getValue());
		}
	

    	
    	}
    }
	public static void main(String[] args) {
		String str="java with selenium";
		count(str);

	}

}
