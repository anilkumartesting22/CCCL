package Core_Java;

public class Heirachical_Class_C extends Heirachical_Class_A{

	public static void main(String[] args) {
		Heirachical_Class_C ob2=new Heirachical_Class_C();
		System.out.println(ob2.Mul());
		ob2.Sub();

	}

}
