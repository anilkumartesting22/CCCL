package Core_Java;

public class Else_if_Exp1 {

	public static void main(String[] args) {
		int a=45+34;
		if(a>340)
		{
			System.out.println("One");
		}
		else if(a>239)
		{
			System.out.println("two");
		}
		else if(a==12)
		{
			System.out.println("Three");
		}
		else if(a>234)
		{
			System.out.println("Four");
		}
		else
		{
			System.out.println("Condition fail");
		}

	}

}
