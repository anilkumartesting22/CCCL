package Core_Java;

public class Arrays_Exp2 {

	public static void main(String[] args) {
		//syntax of array
		//store values
		int[][] b=new int[2][2];
		b[0][0]=34;
		b[0][1]=78;
		b[1][0]=56;
		b[1][1]=89;
		System.out.println("the value of array is:"+b[0][1]);

	}

}
