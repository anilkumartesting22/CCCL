package Core_Java;

public class Heirachical_Class_B extends Heirachical_Class_A{

	public static void main(String[] args) {
		Heirachical_Class_B obj=new Heirachical_Class_B();
		obj.Add(34, 56);
		obj.Div();

	}

}
