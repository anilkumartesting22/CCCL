package Core_Java;

public class String_Starts_Pre {

	public static void main(String[] args) {
		String name="Selenium is Automation tool";
		boolean a=name.startsWith("u", 6);
	//System.out.println(a);
		if(a)
		{
			System.out.println("That is True");
		}
		else
		{
		System.out.println("that is false");
		}
	}

}
