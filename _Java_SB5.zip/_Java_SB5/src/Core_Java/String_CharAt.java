package Core_Java;

public class String_CharAt {

	public static void main(String[] args) {
		String name="Selenium is Automation tool";
		int a=name.length();
		char b=name.charAt(13);
		System.out.println("The 13th position is:"+b);
		char c=name.charAt(0);
		System.out.println("The first position is:"+c);
		for(int i=0; i<name.length();i++)
		{
			char f_name=name.charAt(i);
			System.out.print(f_name);
		}

	}

}
