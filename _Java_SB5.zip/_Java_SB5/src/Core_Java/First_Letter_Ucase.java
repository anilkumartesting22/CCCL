package Core_Java;

public class First_Letter_Ucase {

	public static void main(String[] args) {
		String name=" selenium java pyhton";
		String reca=name.replaceAll("\\{2,}", " ").trim();
		String[] sp=reca.split(" ");
		for(String word:sp)
		{
			System.out.println("The first value is:"+word.substring(0,1).
					toUpperCase()+word.substring(1, word.length())+" ");
		}
	}

}
