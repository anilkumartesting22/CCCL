package Core_Java;

public class String_Starts_With {

	public static void main(String[] args) {
		String slogan="jana gana mana";
		boolean a=slogan.startsWith("jana");
		if(a)
		{
			System.out.println("The starts with jana");
		}
		else
		{
			System.out.println("Not starts with jana");
		}
		boolean b=slogan.endsWith("mana");
		if(b)
		{
			System.out.println("Ends with mana");
		}
		else
		{
			System.out.println("Not Ends with mana");
		}

	}

}
