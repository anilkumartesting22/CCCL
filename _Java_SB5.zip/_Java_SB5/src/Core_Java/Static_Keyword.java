package Core_Java;

public class Static_Keyword {
	public static void Add(int a,int b)
	{
		int c= a+b;
		System.out.println(c);
	}
	public static void Mul()
	{
		int d=23*43;
		System.out.println(d);
	}
	public static void Div()
	{
		int v=35/7;
		System.out.println(v);
	}
	public static void Sub()
	{
		int s=245;
		int y=123;
		int o=s-y;
		System.out.println(o);
	}

	public static void main(String[] args) {
		//Static_Keyword obj=new Static_Keyword();
		Static_Keyword.Add(23, 45);
		Static_Keyword.Div();
		Static_Keyword.Sub();
		Static_Keyword.Mul();

	}

}
