package Core_Java;

public class Heirachical_Class_A {
	//we need to provide methods 
	public void Add(int a, int b)
	{
		int c=a+b;
		System.out.println(c);
	}
	public void Div()
	{
		int v=12/2;
		System.out.println(v);
	}
	public int Mul()
	{
		int k=56*12;
		return k;
	}
	public void Sub()
	{
		int d=245;
		int y=122;
		int u=d-y;
		System.out.println(u);
	}


}
