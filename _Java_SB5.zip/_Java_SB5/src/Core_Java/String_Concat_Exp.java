package Core_Java;

public class String_Concat_Exp {

	public static void main(String[] args) {
		String name1="Selenium";
		String name2=" with java";
		String full_name=name1.concat(name2);
		System.out.println(full_name);
		
		
		
		

	}

}
