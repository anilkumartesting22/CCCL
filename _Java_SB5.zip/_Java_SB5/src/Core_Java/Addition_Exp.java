package Core_Java;

public class Addition_Exp {

	public static void main(String[] args) {
		//Add the data
		int a=56;
		int b=76;
		//add a+b values
		int c=a+b;
		System.out.println("The value of addition is..:"+c);
		//sub
		int d=245;
		int e=123;
		int i=d-e;
		System.out.println("The value od sub is..:"+i);
		//Mul
		int z=23;
		int y=89;
		int j=z*y;
		System.out.println("The value of Mul is..:"+j);
		//Div
		int s=35;
		int u=5;
		int v=s/u;
		System.out.println("The value of Div is..:"+v);
		

	}

}
