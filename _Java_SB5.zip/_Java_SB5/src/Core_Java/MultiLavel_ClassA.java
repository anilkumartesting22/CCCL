package Core_Java;

public class MultiLavel_ClassA {
//we need to provide some methods 
	public void Add()
	{
		int a=23+67;
		System.out.println("The value addition is..:"+a);
	}
	public int div()
	{
		int b=35/5;
		return b;
		
	}
	public void Sub()
	{
		int d=234;
		int s=123;
		int y=d-s;
		System.out.println("The value of Sub:.."+y);
	}
	public void Mul()
	{
		int f=34*12;
		System.out.println("The value of Mul is:.."+f);
	}
}
