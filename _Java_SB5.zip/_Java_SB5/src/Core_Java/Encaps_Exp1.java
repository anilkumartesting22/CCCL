package Core_Java;

public class Encaps_Exp1 {
	private String stu_name;
	private int stu_id;
	private int stu_Batch;
	private String stu_section;
	public String getname()
	{
		return stu_name;
		
	}
	public void setname(String name)
	{
		this.stu_name=name;
		
	}
	public int getid()
	{
		return stu_id;
	}
	public void setid(int stuid)
	{
		this.stu_id=stuid;
	}
	public int getbatch()
	{
		return stu_Batch;
	}
	public void setbatch(int stubatch)
	{
		this.stu_Batch=stubatch;
	}
	public String getSection()
	{
		return stu_section;
	}
	public void setSection(String stusection)
	{
		this.stu_section=stusection;
	}
	

	public static void main(String[] args) {
		Encaps_Exp1 obj=new Encaps_Exp1();
		obj.setname("Selenium");
		obj.setid(786);
		obj.setbatch(2004);
		obj.setSection("Java");
        System.out.println(obj.getname());
        System.out.println(obj.getid());
        System.out.println(obj.getbatch());
        System.out.println(obj.getSection());

	}

}
