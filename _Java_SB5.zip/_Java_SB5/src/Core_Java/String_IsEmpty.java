package Core_Java;

public class String_IsEmpty {

	public static void main(String[] args) {
		String name="";
		boolean a=name.isEmpty();
		System.out.println(a);
		
		String name3=" ";
		boolean b=name3.isBlank();
		System.out.println(b);

	}

}
