package Core_Java;

public class Single_Inheritance_ClassB extends Single_Inheritance_ClassA {

	public static void main(String[] args) {
		Single_Inheritance_ClassB obj=new Single_Inheritance_ClassB();
		System.out.println(obj.name);
		System.out.println(obj.name2);
		obj.Add();
		obj.div();

	}

}
