package Core_Java;

public class length_Exp1 {

	public static void main(String[] args) {
		//get the length
		int[] a= {4,2,6,8,1,7,3,9,10,5};
		int len=a.length;
		System.out.println("The size og int Array is:"+len);

	}

}
