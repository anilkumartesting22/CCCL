package Core_Java;

public class Array_Exp {
    
	public static void main(String[] args) {
		//syntax of array
		//store the values
		int[] a=new int[4];
		a[0]=45;
		a[1]=67;
		a[2]=89;
		a[3]=12;
		
		System.out.println("The value of Array is:"+a[2]);
	

	}

}
