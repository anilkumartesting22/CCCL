package Core_Java;

import java.util.Arrays;

public class Bobble_Sor_Exp2 {

	public static void main(String[] args) {
		int[] a= {4,2,6,8,1,7,3,9,10,5};
		System.out.println("Before sorting:"+Arrays.toString(a));
		//get the length of Container
		int n=a.length;
		for(int i=0;i<n-1;i++)//this will be validate swap is required or not
		{
			for(int j=0;j<n-1;j++)//swap is required 
			{
				if(a[j]>a[j+1])//condition will execute
				{
					int temp=a[j];// temp=4
					a[j]=a[j+1];   // 1=2,2=3
					a[j+1]=temp;//2=4
				}
			}
		}
		System.out.println("Afeter sorting:"+Arrays.toString(a));
		

	}

}
