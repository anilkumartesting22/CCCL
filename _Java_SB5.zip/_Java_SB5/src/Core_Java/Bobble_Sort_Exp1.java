package Core_Java;

import java.util.Arrays;
import java.util.Collections;

public class Bobble_Sort_Exp1 {

	public static void main(String[] args) {
		//store the values
		Integer[] a= {4,2,6,8,1,7,3,9,10,5};
		//Before sorting
		System.out.println("Before bubble sort:"+Arrays.toString(a));
		Arrays.sort(a,Collections.reverseOrder());
		//Arrays.parallelSort(a);
		System.out.println("After sorting:"+Arrays.toString(a));

	}

}
