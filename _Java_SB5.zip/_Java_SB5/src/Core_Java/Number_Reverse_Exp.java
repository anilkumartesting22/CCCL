package Core_Java;
import java.util.*;
public class Number_Reverse_Exp {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Mr User please provide the Palindrum number");
		int num=sc.nextInt();
		int con=num;
		int rev=0;
		while(num!=0)
		{
			rev=rev*10+num%10;//786
			num=num/10;
		}
		//System.out.println(rev);
		if(rev==con)
		{
			System.out.println("This is palindrum");
		}
		else
		{
			System.out.println("this is not a Palindrum");
		}

	}

}
