package Core_Java;
class prime
{
	//String name="Hello selenium";
	prime()
	{
		System.out.println("This is Super");
		//System.out.println(name);
	}
}
class hai extends prime
{
	//String name="Heloo java";
	hai()
	{
		super();
		//super.jai();
		System.out.println("This is also super");
		//System.out.println(super.name);
		//System.out.println(name);
	}
}
public class Super_Key_Exp {

	public static void main(String[] args) {
		hai obj=new hai();
	//	obj.jai();
		//obj.kanishk();

	}

}
