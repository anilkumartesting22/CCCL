package Core_Java;

public class Method_overriding_Exp1 {
	  public void Selenium(String name,String name2)
	  {
		 System.out.println(name); 
		 System.out.println(name2);
	  }
	  public void Selenium(int age,String name3)
	  {
		  System.out.println(age);
		  System.out.println(name3);
	  }
	  public void Selenium(String Empname, int age)
	  {
		  System.out.println(Empname);
		  System.out.println(age);
	  }

}
