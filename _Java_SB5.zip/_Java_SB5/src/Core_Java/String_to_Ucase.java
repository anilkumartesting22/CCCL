package Core_Java;

public class String_to_Ucase {

	public static void main(String[] args) {
		String name="SeleNIUm With JAva";
		String low_case=name.toLowerCase();
		System.out.println(low_case);
		String name3="JavA WITh PyChOn";
		String u_case=name3.toUpperCase();
		System.out.println(u_case);
	}

}
