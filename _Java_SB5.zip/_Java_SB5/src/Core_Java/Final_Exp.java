package Core_Java;
final class H
{
	
	
	final void Selenium()
	{
		
	}
}
class K 
{
	final int  a=67;
	public void Selenium()
	{
		
	}
	
}
public class Final_Exp  {

	public static void main(String[] args) {

		K obj=new K();
	//	obj.a=54;
		
		
		

	}

}
