package Core_Java;

public class For_Each_loop {

	public static void main(String[] args) {
		//store the values
		int[] a= {3,5,7,9,13,18,19};
		for(int c:a)
		{
			System.out.println(c);
		}
		

	}

}
