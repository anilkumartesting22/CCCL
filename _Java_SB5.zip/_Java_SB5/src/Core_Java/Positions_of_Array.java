package Core_Java;

public class Positions_of_Array {
	
	public static void main(String[] args) {
		String[] a= {"java","Ruby","C#","Python","Tablue"};
		for(int i=0;i<a.length;i++)
		{
			System.out.println("The position of array:"+ i +" is:"+a[i]);
		}
     System.out.println(a[3].length());
}
}
