package Core_Java;

public class Prime_Number_Exp {

	public static void main(String[] args) {
		//print the prime number 1--100
		int num=100;
		for(int i=2;i<=num;i++)
		{
			int count=0;//1-2-3
			{
				for(int j=2;j<i;j++)
				{
					if(i%j==0)
					{
						count++;
					}
				}
				if(count==0)
				{
					System.out.println(i+" ");
				}
			}
		}

	}

}
