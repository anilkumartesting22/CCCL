package Core_Java;
import java.util.*;
public class Second_Reverse_String {

	public static void main(String[] args) {
		//syntax of Scanner
		Scanner sc=new Scanner(System.in);
		//provide the data from console
		System.out.println("Enter First,second,third names");
		String names=sc.nextLine();
		
		//split the names
		String[] full_name=names.split("\\s");
		
		//provide the arrary Index number
		String first=full_name[0];
		String Second=full_name[1];
		String Third=full_name[2];
		
		//Reverse expected String
		
		String common=new StringBuilder(Third).reverse().toString();
		//print the names
		System.out.println("The name of first is:"+first);
		System.out.println("The name of Third_Reverse is:"+common);
		System.out.println("The name of Second is:"+Second);
		
		
		
		
		
	}

}
