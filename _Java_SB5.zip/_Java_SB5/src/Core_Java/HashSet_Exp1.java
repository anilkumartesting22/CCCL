package Core_Java;
import java.util.*;
public class HashSet_Exp1 {

	public static void main(String[] args) {
		//syntax of the HashSet
		HashSet<Integer> stu=new HashSet<Integer>();
		//store the stuid's
		stu.add(23);
		stu.add(45);
		stu.add(78);
		stu.add(12);
		stu.add(56);
		stu.add(87);
		stu.add(23);
		//get the size
		System.out.println(stu.size());
		System.out.println("===========");
		//all the stu Id's
		for(Integer ids:stu)
		{
			System.out.println("The number of id's is:"+ids);
		}
		System.out.println("===========");
		//remove the one student
		stu.remove(56);
		//the Value is avilable or not
		for(Integer id:stu)
		{
			System.out.println(id);
		}
		System.out.println("===========");
		//need to cross check
		if(stu.contains(56))
		{
			System.out.println("The value is available");
		}
		else
		{
			System.out.println("The value is not available");
		}
		
		

	}

}
