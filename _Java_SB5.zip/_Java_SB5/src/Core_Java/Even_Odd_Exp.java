package Core_Java;

public class Even_Odd_Exp {

	public static void main(String[] args) {
	//store the values in my container
     int[] a= {2,5,6,1,3,7,8,12,19,17};
     //use the for each loop
     for(int c:a)
     {
    	 if(c%2!=0)
    	 {
    		 System.out.println(c);
    	 }
     }
     System.out.println("print Odd numbers....");
	
	for(int c:a)
	{
		if(c%2==0)
		{
			System.out.println(c);
		}
	}
	System.out.println("Even numbers...");
	}
}
