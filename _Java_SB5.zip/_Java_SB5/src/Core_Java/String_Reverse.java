package Core_Java;

public class String_Reverse {

	public static void main(String[] args) {
		//store the String in one variable
		String name="Python";
		//Empty variable in future puspose
		String str="";
		int len=name.length();//8
		for(int i=len-1;i>=0;i--)//8-0=m8-1u
		{
			str=str+name.charAt(i);//muineleS
		}
		System.out.println(str);

	}

}
