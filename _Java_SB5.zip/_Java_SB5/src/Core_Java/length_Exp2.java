package Core_Java;

public class length_Exp2 {

	public static void main(String[] args) {
		String[] a= {"java","python","Ruby","Selenium"};
		int len=a.length;
		System.out.println("The length of array is:"+len);
		System.out.println("The number of Char is:"+a[3].length());

	}

}
