package Core_Java;

public class Break_Exp1 {

	public static void main(String[] args) {
		//i have 10 testcases 
		for(int i=1;i<=10;i++)
		{
			System.out.println(i);
			if(i==5)
			{
				break;
			}
		}

	}

}
